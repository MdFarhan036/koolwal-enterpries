# Koolwal Enterprises - HTML CSS JS Website

This is a static/manual-data mini ecommerce website. No React, Node.js, database, or backend is required.

## Run
Simply open `index.html` in a browser.

## Pages
- Home
- Products
- Product detail
- Categories
- Category detail
- About
- Business enquiry
- Enquiry cart

## Manual data
All categories and products are stored in:
`js/data.js`

Edit that file to add/change products, prices, brands, categories and images.

## Cart
The enquiry cart uses browser localStorage only. It is not a server/database cart.

## Production later
A backend/admin panel can be connected later for dynamic product management.
